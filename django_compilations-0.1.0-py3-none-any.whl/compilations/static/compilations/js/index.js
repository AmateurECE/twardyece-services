/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./js/index.js":
/*!*********************!*\
  !*** ./js/index.js ***!
  \*********************/
/***/ (() => {

eval("///////////////////////////////////////////////////////////////////////////////\n// NAME:            index.js\n//\n// AUTHOR:          Ethan D. Twardy <edtwardy@mtu.edu>\n//\n// DESCRIPTION:     Main script for the page.\n//\n// CREATED:         07/26/2021\n//\n// LAST EDITED:     08/28/2021\n////\n\nlet videoList; // Global state!?\nlet videoBoxOne;\nlet videoBoxTwo;\n\nfunction getMeta(metaName) {\n    const metas = document.getElementsByTagName('meta');\n\n    for (let i = 0; i < metas.length; i++) {\n        if (metas[i].getAttribute('name') === metaName) {\n            return metas[i].getAttribute('content');\n        }\n    }\n\n    return '';\n}\n\nclass ApiClient {\n    constructor(rootUrl) {\n        this.rootUrl = rootUrl;\n        this.csrfmiddlewaretoken = document.querySelector(\n            '[name=csrfmiddlewaretoken]').value;\n    }\n\n    async jsonFetch(endpoint) {\n        const response = await fetch(\n            this.rootUrl + endpoint,\n            {headers: {'Content-Type': 'application/json'}}\n        );\n\n        if (!response.ok) {\n            throw Error(response.statusText);\n        }\n\n        return response.json();\n    }\n\n    async jsonDelete(endpoint) {\n        const response = await fetch(\n            this.rootUrl + endpoint, {\n                method: 'DELETE',\n                headers: {\n                    'Content-Type': 'application/json',\n                    'X-CSRFToken': this.csrfmiddlewaretoken,\n                }\n            }\n        );\n\n        if (!response.ok) {\n            throw Error(response.statusText);\n        }\n\n        return {};\n    }\n}\n\nasync function kickoffVideoLoop() {\n    const boxElement = document.getElementById(this.elementId);\n    if (boxElement.firstElementChild !== null) {\n        const videoElement = boxElement.firstChild;\n        boxElement.removeChild(videoElement);\n    }\n    if (this.videoBox !== undefined) {\n        await this.client.jsonDelete('videos/' + this.videoBox.name + '/');\n    }\n\n    const videoElement = document.createElement('video');\n    videoElement.setAttribute('controls', '');\n    boxElement.appendChild(videoElement);\n\n    let video = videoList.videos.shift();\n    let sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));\n    if (video === undefined) {\n        while (true) {\n            if (videoList.after !== null) {\n                videoList = await this.client.jsonFetch(\n                    'videos/' + `?after=${videoList.after}`\n                        + `&count=${videoList.count}`);\n                console.log(videoList);\n                if (videoList.videos.length === 0) {\n                    await sleep(2000);\n                } else {\n                    video = videoList.videos.shift();\n                    break;\n                }\n            } else {\n                break;\n            }\n        }\n    }\n\n    if (video !== undefined) {\n        this.videoBox = video;\n        const url = await this.client.jsonFetch('videos/' + video.guid + '/');\n        videoElement.src = url;\n        console.log(videoElement.src);\n        videoElement.addEventListener(\n            'ended', kickoffVideoLoop.bind(this), false);\n        videoElement.addEventListener(\n            'canplaythrough', async () => { await videoElement.play(); });\n    }\n}\n\nasync function main() {\n    const button = document.getElementById('start');\n    button.parentNode.removeChild(button);\n\n    const box1 = document.createElement('div');\n    box1.classList.add('video-box');\n    box1.id = 'box-1';\n    const box2 = document.createElement('div');\n    box2.classList.add('video-box');\n    box2.id = 'box-2';\n    const videoPlayer = document.getElementById('player');\n    videoPlayer.appendChild(box1);\n    videoPlayer.appendChild(box2);\n\n    const apiUrl = getMeta('api-base');\n    const client = new ApiClient(apiUrl);\n    videoList = await client.jsonFetch('videos/');\n\n    const loop1 = kickoffVideoLoop.bind({\n        client, elementId: 'box-1', videoBox: videoBoxOne});\n    await loop1();\n\n    const loop2 = kickoffVideoLoop.bind({\n        client, elementId: 'box-2', videoBox: videoBoxTwo});\n    await loop2();\n}\n\nwindow.addEventListener('DOMContentLoaded', () => {\n    const button = document.createElement('button');\n    button.id = 'start';\n    button.addEventListener('click', main, false);\n    button.appendChild(document.createTextNode('Start'));\n    document.body.appendChild(button);\n    // main().catch(error => console.error(error));\n});\n\n///////////////////////////////////////////////////////////////////////////////\n\n\n//# sourceURL=webpack://django-compilations/./js/index.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./js/index.js"]();
/******/ 	
/******/ })()
;