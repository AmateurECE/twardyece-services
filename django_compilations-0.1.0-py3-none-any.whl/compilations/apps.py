from django.apps import AppConfig


class CompilationsConfig(AppConfig):
    name = 'compilations'
